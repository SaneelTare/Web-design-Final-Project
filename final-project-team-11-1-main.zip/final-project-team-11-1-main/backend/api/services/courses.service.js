
const courseListMongooseService = require('../mongoose/courseList/courseListMongoose.service');
const _ = require('lodash');

//this is used to get coursebyID, search by coursename and in conditions in repsect if courseId is empty then according to it responses are sent 


function getCourseById(query) {
    const {courseId} = query;
    if(_.isEmpty(courseId)) {
        return {success: false, message: 'CourseId is required for query'};
    }
    return courseListMongooseService.getCourseById(courseId).then(res => {
        return {success: true, data: res}
    });
}

function searchCourseByName(body) {
    const  {courseName} = body;
    if (_.isEmpty(courseName)) {
        return {success: false, message: 'CourseId is required for query'};
    }
    return courseListMongooseService.searchCourseByName(courseName).then(res => {
        return {success: true, data: res}
    });
}

function getAllCourses(query) {
    query = query ? query : {};
    return courseListMongooseService.getAllCourses(query).then(res => {
        return {success: true, data: res}
    });;
}
//this is used to save couse in case there is course where some params are missing , it will not happen ,else the course will be saved
function saveNewCourse(courseInfo) {
    const  {courseName, instructor, description, updateDate, price, imageLink} = courseInfo;
    if (!courseName || !instructor || !price || !imageLink) {
        return {success: false, message: 'Required Fields missing'};
    }
    return courseListMongooseService.saveNewCourse({courseName, instructor, description, updateDate, price, imageLink}).then(res => {
        return {success: true, data: res.toObject()}
    });
}

module.exports = {
    getCourseById,
    searchCourseByName,
    getAllCourses,
    saveNewCourse
}