

const userCoursesMongooseService = require('../mongoose/userCourses/userCoursesMongoose.service');
//getusercourses and registercourses is checked and on basis of it success or failure is checked
function getUserCourses(query) {
    const {userId, rpp, page} = query;
    if(!userId) {
        return {success: false, message: 'UserId is required for query'};
    }
    return userCoursesMongooseService.getUserCourses(query).then(res => {
        return {success: true, data: res}
    });;
}

//this is defines specially for user course , in casse userid, coursename or courseId is missing then error is success is fail , else it is registeres course

function registerCourse(body) {
    const {userId, courseName, courseId} = body;
    const purchaseDate = new Date();
    if(!userId || !courseName || !courseId) {
        return {success: false, message: 'Required Fields missing for registration'};
    }
    const userCourse = {userId, courseName, courseId, purchaseDate}
    return userCoursesMongooseService.registerCourse(userCourse).then(res => {
        return {success: true, data: res}
    });;
}

module.exports = {
    getUserCourses,
    registerCourse
}