const router = require('express').Router();
//here routes are defined for auth for login and signup , then the request body is given to authController to check for signup and login
router.post('/login', login);
router.post('/signup', signup);
module.exports = router;

const authController = require('../controllers/auth.controller');

function login(req, res, next) {
    const body =  req.body;
    res.resolveAndResponse(
        authController.login(body),
        next
    );
}

function signup(req, res, next) {
    const body =  req.body;

    res.resolveAndResponse(
        authController.signup(body),
        next
    );
}