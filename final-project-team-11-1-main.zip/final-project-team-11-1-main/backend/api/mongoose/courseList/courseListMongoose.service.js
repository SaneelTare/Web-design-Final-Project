
const courseListMongooseStore = require('./courseListMongoose.store');

//used for to check savenewcourse,getallcourse amd get courseby id is seen
//query are passes in return the mongooseStore is called to get return type from them

function saveNewCourse(courseInfo) {
    return courseListMongooseStore.saveNewCourse(courseInfo);
}

function getAllCourses(query) {
    const {rpp, page} = query;
    const mongoOptions = {};
    if (rpp && page) {
        mongoOptions['limit'] = rpp;
        mongoOptions['skip'] = (page -1) * rpp;
    }
    return courseListMongooseStore.getAllCourses({}, mongoOptions);
}

function getCourseById(courseId) {
    return courseListMongooseStore.getCourseById(courseId);
}

function searchCourseByName(courseName) {
    return courseListMongooseStore.searchCourseByName(courseName);
}

module.exports = {
    saveNewCourse,
    getAllCourses,
    getCourseById,
    searchCourseByName
}