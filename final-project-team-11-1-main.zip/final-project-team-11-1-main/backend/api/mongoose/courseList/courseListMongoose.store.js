
//data fromCourseListMongoose.service comes here and it check for data in side the model
const mongoConnection = require('../mongoConnection');
const mongo = new mongoConnection();
const models = mongo.models;
const courseListModel = models.courseList;

function saveNewCourse(courseInfo) {
    const newCourse = new courseListModel({...courseInfo});
    return newCourse.save();
}
//spread syntax is used for courseInfo

function getAllCourses(query, options) {
    return courseListModel.find(query, {}, options).lean().exec();
}
 /** Sets the lean option. */
function getCourseById(courseId) {
    return courseListModel.findOne(courseId).lean().exec();
}

function searchCourseByName(courseName) {
    return courseListModel.find({courseName}).lean().exec();
}

module.exports = {
    saveNewCourse,
    getAllCourses,
    getCourseById,
    searchCourseByName
}