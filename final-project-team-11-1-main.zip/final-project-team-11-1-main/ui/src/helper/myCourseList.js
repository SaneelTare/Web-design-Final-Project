import React from "react";

//the strcuture of mycourseList is defined here , in function of myCourseList parameters are passed 
//the values are then assigned , and date of registeration is changed to LoacaleDateString() format
const formatDate = (date) => new Date(date).toLocaleDateString();

function myCourseList ({courseID,courseName,purchaseDate}){

    return (
        <div className="courseCategoryItem">
          <h3> {courseID} </h3>
          <h1> {courseName} </h1>
          <p>Course Registered Date: {formatDate(purchaseDate)} </p>            
        </div>
    )
}

export default myCourseList;