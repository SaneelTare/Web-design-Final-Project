import { useContext } from "react"; //useContext” hook is used to create common data that can be accessed throughout the component hierarchy without passing the props down manually to each level.
import { AppContext } from "../context/AppContext";
const formatDate = (date) => new Date(date).toLocaleDateString();
//in function CourseCategoryItem params are passed 

function CourseCategoryItem ({ courseId, courseName, instructor, description, updateDate, price, imageLink}){
  const { setMyCourses } = useContext(AppContext);
  
  const handleBuyCourse = () => {
    const userData = JSON.parse(localStorage.getItem('userData'));

    const reqBody = {
      courseName,
      courseId,
      userId: userData._id,
      purchaseDate: new Date().toISOString(),
    }

    fetch('http://localhost:3001/userCourses/registerCourse', { // we have used POST for the register course
      method: 'POST',
      body: JSON.stringify(reqBody),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': localStorage.getItem('sessionToken') //we have got session token from localstorage and then passed it to x-access token
      }
    })
    .then(response => response.json())
    .then(data => { 
      console.log(data); 
      setMyCourses((prev) => [...prev, data.data]); //when data is recieved then we call function setMycourses to define coures
      alert("Course registered successfully")
    });
  }

    return (
        <div className="courseCategoryItem">
          
          <h1> Course Name : {courseName} </h1>
          <h3> Instructor :{instructor} </h3>
          <p> Description <br/>{description} </p>
          <br/>
          <p> Updated Date: <br/>{formatDate(updateDate)} </p>  
          <img src={imageLink} alt={courseName}/>
          <p>Price : {price}</p>          
          <button onClick={handleBuyCourse}>Buy This Course</button>
          </div>
  );

  //onclick of buy this course we call function handleBuyCourse
}

export default CourseCategoryItem;

