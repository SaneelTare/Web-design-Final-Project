import { createContext, useState } from "react";



//AppContext is used to provide global update , here it is being used to check whether a user has logged in or not 
//and is passed in index.js and used in navbar to check if user has logged in then what changes in navbar needs to show
//courses are set in mycourses on based of user login
export const AppContext = createContext();

const AppContextProvider = ({ children }) => {
    const [isUserLoggedIn, setIsUserLoggedIn] = useState(false);
    const [myCourses, setMyCourses] = useState([]);

    const login = () => setIsUserLoggedIn(true); 
    const logout = () => setIsUserLoggedIn(false); 
    return (
        <AppContext.Provider value={{ isUserLoggedIn, myCourses, login, logout, setMyCourses }}>
            {children}
        </AppContext.Provider>
    );
};

export default AppContextProvider;