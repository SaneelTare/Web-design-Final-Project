import React, { useEffect, useState } from "react";
import OurCourseCategoryItem from "../helper/OurCourseCategoryItem";
import '../Styles/OurCourse.scss';


function TotalCourse() {
  const [Courses, setCourses] = useState([]);
// useeffect is used to tell react that your component needs to do something after render
  useEffect(() => {
    // make http request through fetch
    fetch('http://localhost:3001/courses/getAllCourses', {
      headers: {
        'x-access-token': localStorage.getItem('sessionToken')
      }

      // sessionn token stored in x-access and then courses set 
    }).then(response => response.json()).then(data => { console.log(data); setCourses(data.data); });
  }, [])

  return (
    <div className="ourcourse">
      <h1 className="courseTitle">Our Courses</h1>

      <div className="courseList">
        {Courses.map((myCourseList, key) => {
          return (
            <OurCourseCategoryItem
              key={key}
              courseId={myCourseList._id}
              courseName={myCourseList.courseName}
              instructor={myCourseList.instructor}
              description={myCourseList.description}
              updateDate={myCourseList.updateDate}
              imageLink={myCourseList.imageLink}
              price={myCourseList.price}
            />
          );

          // prosps are passed here an based on tags data is fetched
        })}
      </div>
    </div>


  );

}

export default TotalCourse;