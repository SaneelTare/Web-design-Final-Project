import React, { Component } from 'react';
import YouTube from 'react-youtube';
//recact youtube uses youtube api internally
//https://youtu.be/k_2ZIGw8wN8
//https://www.youtube.com/watch?v=k_2ZIGw8wN8
class Youtube2 extends Component {
    //call back method
    VideoOnReady(event) {
        // access to player in all event handlers via event.target
        event.target.pauseVideo();
    }
    render() {
        //change height as width as per screen dimensions to display video in small or wide mode
        const opts = {
            height: '600',
            width: '1500',
            playerVars: {
                // https://developers.google.com/youtube/player_parameters
                autoplay: 1,
            },
        };
        // const {videoId} =this.props
        // eN2z16BKFZTB6rWn
        return <YouTube
         videoId="YqQx75OPRa0"
         //based on the embedd id ye populate above field so that particular video gets played
        //  {videoId}
            opts={opts}
            onReady={this.VideoOnReady} />;
    }


}

export default Youtube2;
