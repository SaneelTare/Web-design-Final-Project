import {useState} from 'react' 
import {useHistory} from 'react-router-dom' /*useHistory hook gives you access to the history instance that you may use to navigate. import { useHistory } from "react-router-dom"*/
import '../Styles/Register.scss'
function Register(){ 

    const history = useHistory()

    const[userName,setUserName]=useState("");  /*useState is a Hook that allows you to have state variables in functional components. */
    const [firstName,setFirstName]= useState("");
    const [lastName,setLastName]=useState("");   
    const [email,setEmail]=useState("");        /* You pass the initial state to this function and it returns a variable with the current state value (not necessarily the initial state) and another function to update this value*/
    const [password,setPassword]= useState("");
    const[phone,setphone]=useState("");
    

    async function registerUser(event){  /*The fetch() method in JavaScript is used to request to the server and load the information in the webpages. The request can be of any APIs that returns the data of the format JSON or XML. This method returns a promise.*/
        event.preventDefault();
        const response = await fetch('http://localhost:3001/auth/signup', {  /*when calling fetch() with the await keyword, we're telling the async function to stop executing until the promise is resolved, at which point it can resume execution and return the resolved value.*/
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({ /*The JSON. stringify() method converts a JavaScript object or value to a JSON string, optionally replacing values if a replacer function is specified or optionally including only the specified properties if a replacer array is specified.*/
                userName,
                email, 
                phone,
				firstName,
                lastName,
				password,
                
			}),
		})

		const data = await response.json();

        console.log('data', data);
        console.log(data);

		if (data.success) {
            console.log(data);
            let path = `/Login`; 
            history.push(path);  /*pushing in history*/
            
            alert('Register successful')
            
		}
        else{
            alert("Data field missing or dupilicate userName or email")  /* the alert component to be notified whenever an alert message is sent to the alert service and add it to the alerts array for display*/
        }
        
	
    }

   

return(
    <div className="registerForm">
        <h1>Register User</h1>
        <form onSubmit={registerUser}>

        <input 
        value={userName}
        onChange={(e) => setUserName(e.target.value)}  /*e. target. value is the value property of some DOM element, in this case that means the text entered in the search input.*/
        type="text"
        placeholder= "USER NAME" />
        <br/>

        <input 
        value={email}
        onChange={(e)=>setEmail(e.target.value)}
        type="email"
        placeholder= "EMAIL@id" />
        <br/>

        <input 
        value={phone}
        onChange={(e) => setphone(e.target.value)}
        type="text"
        placeholder= "Phone Number" />
        <br/>


        <input 
        value={firstName}
        onChange={(e) => setFirstName(e.target.value)}
        type="text"
        placeholder= "FIRST NAME" />
        <br/>

       <input 
        value={lastName}
        onChange={(e) => setLastName(e.target.value)}
        type="text"
        placeholder= "LAST NAME" />
        <br/>

       

        <input 
        value={password}
        type="password"
        onChange={(e)=>setPassword(e.target.value)}
        placeholder= "password" />
        <br/>

        

        <input type="submit" value="Register"/>
        </form>
    </div>
)

}

export default Register;