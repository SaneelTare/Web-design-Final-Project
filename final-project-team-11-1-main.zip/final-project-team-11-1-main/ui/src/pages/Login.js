import { useContext, useState } from 'react'
import '../Styles/Login.scss';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { useHistory } from "react-router-dom";
import { AppContext } from '../context/AppContext';

function Login() {

  const [userName, setUserName] = useState('');
  const [password, setPassword] = useState('');

  const { login } = useContext(AppContext); 

  const history = useHistory();// The useHistory hook gives you access to the history instance that you may use to navigate.

  const routeChange = () => {
    let path = `register`;
    history.push(path);// The push method is essential and is used to push a path as a route to the history stack, which executes as Last In First Out (LIFO).
  }
  // An async function is a function declared with the async keyword, and the await keyword is permitted within them.
  async function loginUser(event) {
    event.preventDefault();
    const response = await fetch('http://localhost:3001/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      // The JSON.stringify() method converts a JavaScript object or value to a JSON string, optionally replacing values if a replacer function is specified or optionally including only the specified properties if a replacer array is specified.
      body: JSON.stringify({
        userName,
        password,

      }),
    })

    const  data = await response.json()
    console.log(data);

    if (data.success) {
      console.log(5);
      localStorage.setItem('sessionToken', data.data.sessionToken)
      localStorage.setItem('userData', JSON.stringify(data.data))
      alert('Login successful');
      login();
      history.push("/");
      //The history push property returns the URL of the current page. 
    } else {

      console.log(6);
      alert('Please check your username and password')
    }
  }

  return (
    <div className="logindiv">
   {/* ​  The onsubmit property of the GlobalEventHandlers mixin is an event handler that processes submit events. */}
      <form className="loginform" onSubmit={loginUser} >
        <h1><span className="log-in">Log in</span> or <span className="sign-up">sign up</span></h1>

        <p className="float">
          <label for="userName"><i className="icon-lock"></i>UserName</label>
          <input
            value={userName}
            name="userName"
            type="text"
            onChange={(e) => setUserName(e.target.value)}
            placeholder="Enter userName id to login" />
          <br />
        </p>
        {/*The onchange attribute fires the moment when the value of the element is changed.*/}
        <p className="float">
          <label for="password"><i className="icon-lock"></i>Password</label>
          <input
            value={password}
            name="password"
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            placeholder="password" />
          <br />
        </p>

        <p className="clearfix">
 {/* The React onClick event handler enables you to call a function and trigger an action when a user clicks an element */}
          <input type="submit" className="log-twitter" value="New user?Register" onClick={routeChange} />

          <input type="submit" value="Login" />
        </p>
      </form>


    </div>
  )
}

export default Login;