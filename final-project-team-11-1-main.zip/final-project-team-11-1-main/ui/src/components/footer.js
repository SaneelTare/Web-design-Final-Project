import React from "react";


import "../Styles/footer.scss";

function Footer() {
  // java script function is used here
  return (
    <div className="footer">
      <div className="socialMedia">
      
      </div>
      <p> &copy; 2021 CourseRoom.com</p>
    </div>
  );
}

export default Footer;

// Every module can have several named parameters and in order to export one we should use the syntax as follows. 