# CourseRoom

## Team Number : 11

### Team Members :- 
    -Siddhant Kohli (002108396, kohli.sid@northeastern.edu)
    -Yash Navadiya  (002193912, navadiya.y@northeastern.edu)
    -Saneel Tare    (002951543, tare.s@northeastern.edu)
    -Ruchika Sinha  (002193975, sinha.ru@northeastern.edu)


## Description
CourseRoom is a online learning platfrom which is usefull for the students to study various concepts of today's technological world. As a user student will have to first register himself in the register module and then he will be able to login by the username and email id. Student can view the various courses in the CourseRoom and the page will redirect him to the YouTube for more infromation. There are number of courses in the CourseRoom related to the front end development, UI/UX, Cyber Security, Machine Lerning, Data Analytics and many more. We have also provided contacts us features, if students have any doubts they can easily reachout to us by send an emaild used by Sendgrid email API service.

### Skills Learned
    -Client-side Javascript application development and the React library
    -Reactstrap for designing responsive applications
    -context to design the architecture for a React-Redux application
    -Sendgrid Email mailing Api
    -Learned MongoDB database

### How to Run The Site.
1) For the Back-End...
    - First Jump into backend module by typing cd backend.
    - Second step is to get into API folder.
    - Type command node app.js to run the back end on the port 30001

2) For Front-End...
    - First go to ui folder which uderinterface of the project.
    - Type command npm start to run the front end on the port 3000.

